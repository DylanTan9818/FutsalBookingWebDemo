package com.ssk3408.lab.controller;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssk3408.lab.model.Booking;
//import com.ssk3408.lab.model.Staff;
import com.ssk3408.lab.model.Customer;
import com.ssk3408.lab.repository.CustomerRepository;
import com.ssk3408.lab.repository.CourtRepository;
import com.ssk3408.lab.repository.BookingRepository;

@Controller
@RequestMapping("/customers")
public class CustomerController {
private final CustomerRepository customerRepository;
@Autowired
private  BookingRepository bookingRepository;
@Autowired
private CourtRepository courtRepository;
	
	@Autowired
	public CustomerController(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}
	
	@GetMapping("login")
	public String showSignUpForm(Customer customer,Model model) {
		model.addAttribute("customers", customerRepository.findAll());
		return "login";
	}
	
	@GetMapping("signup")
	public String showUpdateForm(Model model) {
		model.addAttribute("customers",customerRepository.findAll());
		return "SignUpFutsal";
	}
	
	@GetMapping("booking")
	public String Booking(Booking booking, Model model) {
		model.addAttribute("bookings",bookingRepository.findAll());
		model.addAttribute("court", courtRepository.findAll());
		return "booking";
	}
	
	@PostMapping("add")
	public String Login(@Valid Customer customer,@Valid Booking booking,BindingResult result, Model model) {
		if(result.hasErrors()) {
			return "login";
		}
		customerRepository.save(customer);
		
		return "homepage";
	}
//
//	@PostMapping("addbooking")
//	public String Booking( @Valid Booking booking, BindingResult result, Model model) {
//		if(result.hasErrors()) {
//			booking.setBookingId(null);
//			return "booking";
//		}
//		Customer user1 = customerRepository.findUserById(1);
//		booking.setCustomer(user1);
//		bookingRepository.save(booking);
//		return "homepage2";
//		}
//	
	
	
	
	@GetMapping("payment_method")
	public String listUsers( Model model) {
	    model.addAttribute("customer", customerRepository.findAll());
	    model.addAttribute("booking", bookingRepository.findAll());
	    return "payment_method";
	}
	
	@GetMapping("delete/{id}")
	public String deleteStaff(@PathVariable("id") long id, Model model) {
		Booking booking = bookingRepository.findById((int) id).orElseThrow(() -> new IllegalArgumentException("Invalid booking Id:" + id));
		bookingRepository.delete(booking);
		model.addAttribute("customer", customerRepository.findAll());
		model.addAttribute("booking", bookingRepository.findAll());
		return "payment_method";
	}
	
//	@GetMapping("update")
//	public String showUpdateMainForm(Model model) {
//		model.addAttribute("futsal", futsalRepository.findAll());
//		return "choose-staff-to-update";
//	}
	
	
	
	
	@GetMapping("edit/{id}")
	public String showUpdateForm(@PathVariable("id") long id, Model model) {
		Booking booking = bookingRepository.findById((int) id).orElseThrow(() -> new IllegalArgumentException("Invalid booking Id: " + id));
		model.addAttribute("booking",booking);
		model.addAttribute("court", courtRepository.findAll());
//		model.addAttribute("departments", departmentRepository.findAll());
		return "update";
	}
	
	@PostMapping("update/{id}")
	public String updateStaff(@PathVariable("id") long id, @Valid Booking booking, BindingResult result, Model model) {
		if(result.hasErrors()) {
			booking.setBookingId((int) id);
			return "index";
		}
		
		bookingRepository.save(booking);
		model.addAttribute("booking", bookingRepository.findAll());
		model.addAttribute("customer", customerRepository.findAll());
		return "payment_method";
	}
	
//	@GetMapping("delete")
//	public String showDeleteMainForm(Model model) {
//		model.addAttribute("futsal",futsalRepository.findAll());
//		return "choose-staff-to-delete";
//	}
	
	@PostMapping("addbooking")
	public String updateStaffProject( @Valid Booking booking,  @RequestParam Integer court_num, @RequestParam Integer num, @RequestParam String date, @RequestParam String start_time, @RequestParam String end_time, @RequestParam String payment_method, BindingResult result, Model model) throws ParseException {
		if(result.hasErrors()) {	
			booking.setId();
			return "index";
		}
		Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(date);  
		Calendar c = Calendar.getInstance();
		c.setTime(date1);
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		String day= " ";
		int price_rate = 0;
		int price = 0;
		Customer user1 = customerRepository.findUserById(1);
		booking.setCustomer(user1);
		
		if(dayOfWeek == 1) {
			day = "Sun";
		}else if(dayOfWeek == 2) {
			day = "Mon";
		}else if(dayOfWeek == 3) {
			day = "Tues";
		}else if(dayOfWeek == 4) {
			day = "Wed";
		}else if(dayOfWeek == 5) {
			day = "Thurs";
		}else if(dayOfWeek == 6) {
			day = "Fri";
		}else {
			day = "Sat";
		}
		
		if((dayOfWeek <=6  && dayOfWeek >=2)) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
		price_rate =  100;
			}else {
				price_rate =  80;
			}
		}else if(dayOfWeek == 1 || dayOfWeek == 7) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
				price_rate =  120;
					}else {
						price_rate =  100;
					}
		}
		
		if((dayOfWeek <=6  && dayOfWeek >=2)) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
		price = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 100;
			}else {
				price = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 80;
			}
		}else if(dayOfWeek == 1 || dayOfWeek == 7) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
				price = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 120;
					}else {
						price = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 100;
					}
		}
		
		
		int hour = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)));

		
		Booking futsal1= new Booking(user1, court_num,num, date1,start_time,end_time,payment_method,price_rate,price,hour,day);
		bookingRepository.save(futsal1);
		return "homepage2";
		
	}
	
	@GetMapping("homepage")
	public String HomePage( Model model) {
	    model.addAttribute("customer", customerRepository.findAll());
	    model.addAttribute("booking", bookingRepository.findAll());
	    return "homepage";
	}
	
	
//	@GetMapping("assign/{id}")
//	public String showAssignProjectForm(@PathVariable("id") long id, @Valid StaffProject staffProject, Model model) {
//		Staff staff = staffRepository.findById((int) id).orElseThrow(() -> new IllegalArgumentException("Invalid staff Id:" + id));
//		model.addAttribute("staff", staff);
//		model.addAttribute("projects", projectRepository.findAll());
//		return "assign-project";
//	}
//	
//	@PostMapping("staffproject/{staffid}")
//	public String updateStaffProject(@PathVariable("staffid") long id1, @Valid Project proj, @RequestParam String startDate, @RequestParam String endDate, @RequestParam String role, @Valid StaffProject staffProject, BindingResult result, Model model) {
//		if(result.hasErrors()) {	
//			staffProject.setId();
//			return "index";
//		}
//		Staff staff = staffRepository.findStaffById((int) id1);
//		Project project = projectRepository.findProjectById(proj.getProjectId());
//		
//		StaffProject staffProject1 = new StaffProject(staff,project,startDate,endDate,role);
//		staffProjectRepository.save(staffProject1);
//		return "index";
//		
//	}
	
//@PostMapping("list")
//	public String showUpdateForm(Model model) {
//		model.addAttribute("futsals", futsalRepository.findAll());
//		return "payment_info";
//	}
	
//	@GetMapping("signup")
//	public String showSignUpForm(Staff staff,Model model) {
//		model.addAttribute("departments", departmentRepository.findAll());
//		return "add-staff";
//	}
//	
//	@GetMapping("list")
//	public String showUpdateForm(Model model) {
//		model.addAttribute("staffs", staffRepository.findAll());
//		return "list-staff";
//	}
//	@PostMapping("add")
//	public String addStaff(@Valid Staff staff, BindingResult result, Model model) {
//		if(result.hasErrors()) {
//			return "add-staff";
//		}
//		
//		staffRepository.save(staff);
//		return "redirect:list";
//		}
//	
//	@GetMapping("update")
//	public String showUpdateMainForm(Model model) {
//		model.addAttribute("staffs", staffRepository.findAll());
//		return "choose-staff-to-update";
//	}
//	
//	@GetMapping("edit/{id}")
//	public String showUpdateForm(@PathVariable("id") long id, Model model) {
//		Staff staff = staffRepository.findById((int) id).orElseThrow(() -> new IllegalArgumentException("Invalid staff Id: " + id));
//		model.addAttribute("staff",staff);
//		model.addAttribute("departments", departmentRepository.findAll());
//		return "update-staff";
//	}
//	
//	@PostMapping("update/{id}")
//	public String updateStaff(@PathVariable("id") long id, @Valid Staff staff, BindingResult result, Model model) {
//		if(result.hasErrors()) {
//			staff.setStaffId((int) id);
//			return "index";
//		}
//		
//		staffRepository.save(staff);
//		model.addAttribute("staffs", staffRepository.findAll());
//		return "index";
//	}
//	
//	@GetMapping("delete")
//	public String showDeleteMainForm(Model model) {
//		model.addAttribute("staffs",staffRepository.findAll());
//		return "choose-staff-to-delete";
//	}
//	
//	@GetMapping("delete/{id}")
//	public String deleteStaff(@PathVariable("id") long id, Model model) {
//		Staff staff = staffRepository.findById((int) id).orElseThrow(() -> new IllegalArgumentException("Invalid staff Id:" + id));
//		staffRepository.delete(staff);
//		model.addAttribute("staffs", staffRepository.findAll());
//		return "index";
//	}
//	
//	@GetMapping("assign")
//	public String assignStaffProject(Model model) {
//		model.addAttribute("staffs", staffRepository.findAll());
//		return "choose-project-to-assign";
//	}
//	
//	@GetMapping("assign/{id}")
//	public String showAssignProjectForm(@PathVariable("id") long id, @Valid StaffProject staffProject, Model model) {
//		Staff staff = staffRepository.findById((int) id).orElseThrow(() -> new IllegalArgumentException("Invalid staff Id:" + id));
//		model.addAttribute("staff", staff);
//		model.addAttribute("projects", projectRepository.findAll());
//		return "assign-project";
//	}
//	
//	@PostMapping("staffproject/{staffid}")
//	public String updateStaffProject(@PathVariable("staffid") long id1, @Valid Project proj, @RequestParam String startDate, @RequestParam String endDate, @RequestParam String role, @Valid StaffProject staffProject, BindingResult result, Model model) {
//		if(result.hasErrors()) {	
//			staffProject.setId();
//			return "index";
//		}
//		Staff staff = staffRepository.findStaffById((int) id1);
//		Project project = projectRepository.findProjectById(proj.getProjectId());
//		
//		StaffProject staffProject1 = new StaffProject(staff,project,startDate,endDate,role);
//		staffProjectRepository.save(staffProject1);
//		return "index";
//		
//	}
//	
//	@GetMapping("display")
//	public String displayStaffProject(Model model) {
//		model.addAttribute("staffs", staffRepository.findAll());
//		return "choose-project-to-display";
//	}
//	
//	@GetMapping("display/{staffid}")
//	public String showDisplayProjectForm(@PathVariable("staffid") long id, Model model) {
//		List<StaffProject> staffProject  = (List<StaffProject>) staffProjectRepository.findStaffProjectByStaffId((int) id);
//		model.addAttribute("staff", staffRepository.findStaffById((int) id));
//		model.addAttr	ibute("staffProjects", staffProject);
//		return "display-project";
//	}

//	
//}
}
