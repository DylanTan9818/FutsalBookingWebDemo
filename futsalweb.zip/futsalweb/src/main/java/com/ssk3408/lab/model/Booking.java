package com.ssk3408.lab.model;

import java.util.Calendar;
//import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
public class Booking {
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "customer_id",referencedColumnName="customer_id")
	
	
	private Customer customer; 
	
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}



	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bookingId")
	private Integer bookingId;
	
	public Booking() {
		super();
	}
	
	
	
	
	
//	public Futsal(User user, Integer court_num, Integer num, Date date, String start_time,
//			String end_time, String payment_method) {
//		super();
//		this.user = user;
//		this.court_num = court_num;
//		this.num = num;
//		this.date = date;
//		this.start_time = start_time;
//		this.end_time = end_time;
//		this.payment_method = payment_method;
//	}
	
//public Futsal(User user, Integer court_num, Integer num, Date date, String start_time,
//			String end_time, String payment_method) {
//		super();
//		this.user = user;
////		this.id = new BookingId(user.getUserId());
//		this.court_num = court_num;
//		this.num = num;
//		this.date = date;
//		this.start_time = start_time;
//		this.end_time = end_time;
//		this.payment_method = payment_method;
//	}
	
	


	@Column(name="court_id")
	private Integer court_num;
	
	public Booking(Customer customer, Integer court_num, Integer num, Date date, String start_time,
		String end_time, String payment_method, Integer price_rate, Integer price, Integer hour, String day) {
	super();
	this.customer = customer;
	this.court_num = court_num;
	this.num = num;
	this.date = date;
	this.start_time = start_time;
	this.end_time = end_time;
	this.payment_method = payment_method;
	this.price_rate = price_rate;
	this.price = price;
	this.hour = hour;
	this.day = day;
}

	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}

	


	@Column(name = "number_people")
	private Integer num;
	
	@Column(name = "bookingdate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date date;
	
	@Column(name = "start_time")
	private String start_time;
	
	@Column(name = "end_time")
	private String end_time;
	
	@Column(name="payment_method")
	private String payment_method;
	
	@Column(name="price_rate")
	private Integer price_rate;
	
	@Column(name="price")
	private Integer price;
	
	@Column(name="number_hours")
	private Integer hour;
	
	@Column(name="day_of_week")
	private String day;
	
//	public BookingId getBookingId() {
//		return id;
//	}

	public String getDay() {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		
		if(dayOfWeek == 1) {
			return "Sun";
		}else if(dayOfWeek == 2) {
			return "Mon";
		}else if(dayOfWeek == 3) {
			return "Tues";
		}else if(dayOfWeek == 4) {
			return "Wed";
		}else if(dayOfWeek == 5) {
			return "Thurs";
		}else if(dayOfWeek == 6) {
			return "Fri";
		}else {
			return "Sat";
		}
		
	}

	public void setDay(String day) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		if(dayOfWeek == 1) {
			this.day = "Sun";
		}else if(dayOfWeek == 2) {
			this.day = "Mon";
		}else if(dayOfWeek == 3) {
			this.day = "Tues";
		}else if(dayOfWeek == 4) {
			this.day = "Wed";
		}else if(dayOfWeek == 5) {
			this.day = "Thurs";
		}else if(dayOfWeek == 6) {
			this.day = "Fri";
		}else {
			this.day = "Sat";
		}
		
	}

	public Integer getHour() {
		return (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)));
	}

	public void setHour(Integer hour) {
		this.hour = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)));
	}

	public Integer getPrice() {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int a = 0;
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		if((dayOfWeek <=6  && dayOfWeek >=2)) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
		return (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 100;
			}else {
				return (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 80;
			}
		}else if(dayOfWeek == 1 || dayOfWeek == 7) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
				return (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 100;
					}else {
						return (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 120;
					}
		}else {
			return a;
		}

		
	}

	public Integer getPrice_rate() {
		
		
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int a = 0;
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		if((dayOfWeek <=6  && dayOfWeek >=2)) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
		return  100;
			}else {
				return  80;
			}
		}else if(dayOfWeek == 1 || dayOfWeek == 7) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
				return  100;
					}else {
						return  120;
					}
		}else {
			return a;
		}
	}

	public void setPrice_rate(Integer price_rate) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		if((dayOfWeek <=6  && dayOfWeek >=2)) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
		this.price_rate =  100;
			}else {
				this.price_rate =  80;
			}
		}else if(dayOfWeek == 1 || dayOfWeek == 7) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
				this.price_rate =  120;
					}else {
						this.price_rate =  100;
					}
		}
		this.price_rate = price_rate;
	}

	public void setPrice(Integer price) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		if((dayOfWeek <=6  && dayOfWeek >=2)) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
		this.price = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 100;
			}else {
				this.price = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 80;
			}
		}else if(dayOfWeek == 1 || dayOfWeek == 7) {
			if(Integer.parseInt(start_time.substring(0,2)) >= 19) {
				this.price = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 120;
					}else {
						this.price = (Integer.parseInt(end_time.substring(0,2)) - Integer.parseInt(start_time.substring(0,2)))* 100;
					}
		}
	}

	public Integer getCourt_num() {
		return court_num;
	}

	public void setCourt_num(Integer court_num) {
		this.court_num = court_num;
	}

	public Integer getNum() {
		return num;
	}




	public Date getDate() {
		return date;
	}




	public String getStart_time() {
		return start_time;
	}




	public String getEnd_time() {
		return end_time;
	}


//	public void setBookingId(BookingId Id) {
//		this.id = Id;
//	}



	public void setNum(Integer num) {
		this.num = num;
	}




	public void setDate(Date date) {
		this.date = date;
	}




	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}




	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

	
	public String getPayment_method() {
		return payment_method;
	}
	public void setPayment_method(String payment_method) {
		this.payment_method = payment_method;
	}
	
	public void setId() {
		// TODO Auto-generated method stub
//		this.id = new BookingId(user.getUserId());

		
	}
}

	
	
	

