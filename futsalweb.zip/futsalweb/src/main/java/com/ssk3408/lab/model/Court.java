package com.ssk3408.lab.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Court {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "court_id")
	private Integer courtId;
	
	@Column(name="court_num")
	private Integer court_num;

	public Court() {
		super();
	}


	public Integer getCourtId() {
		return courtId;
	}


	public void setCourtId(Integer courtId) {
		this.courtId = courtId;
	}


	public Integer getCourt_num() {
		return court_num;
	}

	public void setCourt_num(Integer court_num) {
		this.court_num = court_num;
	}


	
}
