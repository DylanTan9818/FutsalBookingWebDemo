package com.ssk3408.lab.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer {
	
	  @OneToMany(mappedBy = "customer",cascade = CascadeType.ALL)
			private Set<Booking> bookings =
			new HashSet<>();
	  
//	  @OneToMany(mappedBy = "court",cascade = CascadeType.ALL)
//		private Set<Court> courts =
//		new HashSet<>();

	  
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "customer_id")
	private Integer userId;
	

	public Customer() {
		super();
	}
	
	
	public Customer(Integer userId, String emailid, String fname, String lname, String phonenum) {
		super();
		this.userId = userId;
		this.emailid = emailid;
		this.fname = fname;
		this.lname = lname;
		this.phonenum = phonenum;
	}

	public Set<Booking> getFutsals() {
		return bookings;
	}


	public void setFutsals(Set<Booking> bookings) {
		this.bookings = bookings;
	}



	@Column(name= "emailid")
	private String emailid;
	
	@Column(name="fname")
	private String fname;
	
	@Column(name="lname")
	private String lname;
	
	@Column(name="phonenum")
	private String phonenum;


	public String getPhonenum() {
		return phonenum;
	}


	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}


	public Integer getUserId() {
		return userId;
	}


	public String getEmailid() {
		return emailid;
	}

	public String getFname() {
		return fname;
	}


	public String getLname() {
		return lname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public void setUserId(Integer userId) {
		this.userId = userId;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

}
