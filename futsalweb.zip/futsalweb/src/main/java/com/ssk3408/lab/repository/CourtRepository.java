package com.ssk3408.lab.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ssk3408.lab.model.Court;

public interface CourtRepository extends JpaRepository<Court, Integer> {
	
}
